<DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
         <button id='proceed' onclick="window.location.assign('proceed.html');">proceed</button>;
        <button id='cancel' onclick="window.location.assign('index.html');">Cancel</button>;
        
        
    <div class="container">
            <div class="navbar">
            <div class="logo">
                <img src="images/top.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="products.html">Products</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="account.php">My Account</a></li>
                    <li><a href="cart.php">Cart</a></li>
                </ul>
            </nav>
        </div>
        </div>
        
    </body>
</html>

<?php
    $con=mysqli_connect("localhost","root","","clothing_pallet");
    $sql="select * from cart_info";
    $res=mysqli_query($con,$sql);
    $row1=mysqli_num_rows($res);
	    if($row1>0){
		echo "<header>ALL PRODUCTS...</header>";
		$output="<table>
			<td class='heading1'>Product</td>
			<td class='heading1'>Product_Name</td>
			<td class='heading1'>Quantity</td>
			<td class='heading1'>Price</td>
			";
            $Total=0;
		 while($row=mysqli_fetch_array($res)){
             $Total=$Total+$row['Price']*$row['Quantity'];
			$output.="<tr>
			<td><img src=".$row['image']."></td>
			<td>".$row['Product_Name']."</td>
            <td>".$row['Quantity']."</td>
            <td>".$row['Price']."</td>
			
			</tr>";
		}
		$output.="</table>";
		echo $output;
        
        $GrandTotal=$Total+0.1*$Total;
        $output1="<table id='SubTotal'>
        <tr>
            <td>SubTotal : </td>
            <td>".$Total."</td>
        </tr>
        <tr>
            <td>Tax : </td>
            <td>10%</td>
        </tr>
        <tr>
            <td>GrandTotal : </td>
            <td>".$GrandTotal."</td>
        </tr>
        </table>";
            
        echo $output1;
            

       
	}


?>