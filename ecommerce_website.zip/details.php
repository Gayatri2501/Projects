<?php
   
        $src=$_POST['product1'];
        //echo"<img src=".$src.">";
        $pname=$_POST['pname'];
        $price=$_POST['price'];
        
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        
        <div class="container">
            <div class="navbar">
            <div class="logo">
                <img src="images/top.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="products.html">Products</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="account.php">My Account</a></li>
                    <li><a href="cart.php">Cart</a></li>
                </ul>
            </nav>
        </div>
        </div>
        
        
        
        
    <!----------details-------->
        
        <div id="container6">
            <div id="productimage">
                <?php echo"<img src=".$src.">"; ?>
            </div>
            <div id="productdetails">
                <?php echo $pname; ?>
            </div>
            <div id="price">
                <?php echo $price; ?>
                <br>
                <br>
                <form action="" method="post">
                    <select id="size" name="size">
                        <option>select size</option>
                        <option>small</option>
                        <option>medium</option>
                        <option>Large</option>
                        <option>XL</option>
                        <option>XXL</option>
                        <option>XXXL</option>
                    </select>
                    <br>
                    <input id="quantity" value=1 name="quantity" type="number" min=1>
                    <input type="submit" name="submit" value="Add To Cart" id="cart">
                    <input type="hidden" name="product1" value="<?php echo $src; ?>" />
			        <input type="hidden" name="pname" value="<?php echo $pname; ?>" />
			        <input type="hidden" name="price" value="<?php echo $price; ?>" />
                </form>
                <br>
                <h1 id="heading">Product Details</h1>
                <br>
                <p id="para">Give your party wardrobe a style upgrade with womens <br>Active T-Shirt. Team it with a pair of shorts for your morning<br> workout or a denims for an evening out with your girls</p>
                 <button id="goback1" onclick="window.location.assign('index.html');">Go Back</button>
            </div>
            <div id="addedtocart">
                Successfully added to cart!
                <br><br>
                <button id="ok" onclick="closemsg();">Ok</button>
            </div>
        </div>
        <script>
            function closemsg(){
                document.getElementById("addedtocart").style.display="none";
                
            }
            function openmsg(){
                document.getElementById("addedtocart").style.display="block";
            }
        </script>
    </body>
</html>
<?php
    if(isset($_POST['submit']))
        {
            $pname=$_POST['pname'];
            $price=$_POST['price'];
            $quantity=$_POST['quantity'];
            $image=$_POST['product1'];
            $con=mysqli_connect("localhost","root","","clothing_pallet");
            $sql="insert into cart_info(Product_Name,Price,Quantity,image)values('$pname','$price','$quantity','$image')";
            $res=mysqli_query($con,$sql);
            if($res!=false)
            {
                echo "<script>openmsg();</script>";
            }
        }


?>