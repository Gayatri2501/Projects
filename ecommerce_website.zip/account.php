<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Products-Clothing Pallet</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        
        
    
    </head>
        
    <body>
        
        <div class="container">
            <div class="navbar">
            <div class="logo">
                <img src="images/top.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="products.html">Products</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="account.php">My Account</a></li>
                    <li><a href="cart.php">Cart</a></li>
                </ul>
            </nav>
        </div>
        </div>
    
        <!----------account--------->
        <div class="account-page">
            <div class="container">
                <div class="row">
                    <div class="col-2">
                        <img src="images/picture.png" width="100%">
                    </div>
                    
                    <div class="col-2">
                        <div class="form-container">
                            <div class="form-btn">
                                <span onclick="login()">Login</span>
                                <span onclick="register()">Register</span>
                                <hr id="Indicator">
                            </div>
                        
                            <form id="LoginForm" action="" method="post">
                                <input  name="uname" id="uname" type="text" placeholder="Name">
                                <input name="password" id="password" type="password" placeholder="password">
                                <input type="submit" class="btn" value="Login" name="login">
                                <a href="">Forgot Password</a>
                            </form>
                            <div id="invalu">Invalid Username<br><button onclick="closemsg();">Ok</button></div>
                            <div id="invalup">Both Username and Password are Invalid<br><button onclick="closemsg();">Ok</button></div>
                            <div id="invalp">Invalid Password<br><button onclick="closemsg();">Ok</button></div>
                            
                            <form id="RegiForm" action="" method="post" >
                                <input name="uname1" id="uname1" type="text" placeholder="Name">
                                <input name="mail" id="mail" type="email" placeholder="Mail-Id">
                                <input name="pass" id="password1" type="password" placeholder="password">
                                <input type="submit" class="btn" value="Register" name="register">
                            </form> 
                            <div id="regs">Successfully Registered<br><button onclick="homepage();">Ok</button></div>
                            
                        </div> 
                    </div>
                </div>
            </div>
        </div>
        
            
        
        <!--------footer--------->
        
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col-1">
                        <h3>Download Our App</h3>
                        <p>Download App for Android and ios Mobile Phone.</p>
                        <div class="app-logo">
                            <img src="images/both1.jpg">
                        </div>
                    </div>
                    <div class="footer-col-2">
                        <img src="images/last1.jpg">
                    </div>
                    <div class="footer-col-3">
                        <h3>useful links</h3>
                        <ul>
                            <li>Coupouns</li>
                             <li>Return Policy</li>
                             <li>Blog Post</li>
                             <li>Join Affiliate</li>
                        </ul>
                    </div>
                    <div class="footer-col-4">
                        <h3>Follow Us</h3>
                        <ul>
                            <li>Facebook</li>
                             <li>Twitter</li>
                             <li>Instagram</li>
                             <li>YouTube</li>
                        </ul>
                    </div>
                </div>
                <hr>
                <p class="copyright">Copyright@clothingpallet.com</p>
            </div>
        </div>
        
        
        <!-----------js for form-------->
        <script>
            var LoginForm = document.getElementById("LoginForm");
            var RegiForm = document.getElementById("RegiForm");
            var Indicator = document.getElementById("Indicator");
            
            function register(){
                RegiForm.style.transform = "translateX(0px)";
                LoginForm.style.transform = "translateX(0px)";
                Indicator.style.transform = "translateX(100px)";
            }
            
            function login(){
                RegiForm.style.transform = "translateX(300px)";
                LoginForm.style.transform = "translateX(300px)";
                Indicator.style.transform = "translateX(0px)";
            }
            function closemsg()
            {
                document.getElementById("invalu").style.display="none";
                document.getElementById("invalup").style.display="none";
                document.getElementById("invalp").style.display="none";
            }
            function openinvalu()
            {
                    
                    document.getElementById('invalu').style.display='block';
            }
            function openinvalup()
            {
                  
                    document.getElementById('invalup').style.display='block';
            }
            function openinvalp()
            {
                   
                document.getElementById('invalp').style.display='block';
            }
            function homepage()
            {
                window.location.assign("index.html");
            }
            function opensuccess()
            {
                document.getElementById('regs').style.display='block';
            }
            
        </script>
        
    </body>
</html>

<?php
    if(isset($_POST['login']))
    {
        $username=$_POST['uname'];
        $password=$_POST['password'];
       
        $con=mysqli_connect("localhost","root","","clothing_pallet");
        $sql="select * from login where User_Name='$username' and Password='$password'";
        $res=mysqli_query($con,$sql);
        $row=mysqli_num_rows($res);
        if($row<=0)
        {
            
            $sql1="select * from login where User_Name='$username'";
            $res1=mysqli_query($con,$sql1);
            $row1=mysqli_num_rows($res1);
            $sql2="select * from login where Password='$password'";
            $res2=mysqli_query($con,$sql2);
            $row2=mysqli_num_rows($res2);
            if($row1==0 && $row2==0)
            {
                echo "<script>  openinvalup();</script>";
            }
            else if($row1==0)
            {
                 echo "<script>  openinvalu();</script>";
                
            }
            else if($row2==0)
            {
                 echo "<script>  openinvalp();</script>";
            }
        }
        else
        {
            echo "<script>homepage();</script>";
        }
        
    }
        if(isset($_POST['register']))
        {
            $username=$_POST['uname1'];
            $password=$_POST['pass'];
            $mail=$_POST['mail'];
            $con=mysqli_connect("localhost","root","","clothing_pallet");
            $sql="insert into login(User_Name,Password,Email) values('$username','$password','$mail')";
            $res=mysqli_query($con,$sql);
            if($res!=false)
            {
                echo "<script>opensuccess();</script>";
            }
        }
        


?>













